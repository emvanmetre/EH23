from flask import Flask, render_template, request
import pandas as pd

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("results.html")


@app.route("/calculate")
def calculate():
    return render_template("calculate.html", result="")

@app.route("/results")
def resultpage():
    return render_template("results.html", total_week=totalEmissions, total_year=(totalEmissions*52))


# Code for routing to other pages -- implement later
# @app.route("/contact")
# def contact():
#     return render_template("contact.html", prompt="Zipcode", prompt_sel="Select a topic...")
#
#
# @app.route("/about-us")
# def about():
#     return render_template("about.html")

# @app.route("/calculator", method=['POST', 'GET'])
# def calculator():
#    if request.method == 'GET':
#
#    if request.method == '
#    return render_template('calculator.html',form_data = form_data)


@app.route('/results', methods=['POST'])
def results():

    acTotal = 0
    drivingTotal = 0
    foodTotal = 0
    wasteTotal = 0


    aptSize = 0
    bagsOfCoal = 0
    kgOfWood = 0
    gallonsOfHeatingFuel = 0
    oil = 0

    heatingtype = request.form['inputGroupSelect02']
    if heatingtype == "1":
        aptSize = request.form['sqft']
        aptSize = float(aptSize)
    elif heatingtype == "2":
        bagsOfCoal = request.form['coal']
        bagsOfCoal = float(bagsOfCoal)
    elif heatingtype == "3":
        kgOfWood = request.form['wood']
        kgOfWood = float(kgOfWood)
    elif heatingtype == "4":
        gallonsOfHeatingFuel = request.form['oil']
        heatingFuel = request.form['options']
        gallonsOfHeatingFuel = float(gallonsOfHeatingFuel)

        if heatingFuel == "option2":
            oil = gallonsOfHeatingFuel * 39.8182 * 0.25
        elif heatingFuel == "option1":
            oil = gallonsOfHeatingFuel * 36.2603 * 0.24

    else:
        return render_template('calculate.html', result="Please make sure that each input is valid.")




    ## Driving
    doesDrive = request.form['drive']
    drivingTotal = 0
    if doesDrive == "yes":
        typeOfVehicle = request.form['selection-car']
        print(typeOfVehicle)
        milesPerWeek = request.form['miles']
        print(milesPerWeek)
        milesPerWeek = int(milesPerWeek)
        if typeOfVehicle == "3":
            drivingTotal = milesPerWeek * 0.16230
        elif typeOfVehicle == "1":
            drivingTotal = milesPerWeek * 10.75014 / 21.79
        elif typeOfVehicle == "2":
            drivingTotal = milesPerWeek * 0.2



    ## Food Consumption
    foodBeef = request.form['beef']
    foodLamb = request.form['lamb']
    foodPork = request.form['pork']
    foodChicken = request.form['chicken']
    foodEggs = request.form['eggs']
    foodTofu = request.form['tofu']
    foodFish = request.form['fish']
    foodNuts = request.form['nuts']

    eatOutTimes = request.form['timesOut']
    percentLocallySourced = request.form['percent']


    #### Calculations ####


    natgas = int(aptSize) * 10 * 28.32 * 0.19
    coal = int(bagsOfCoal) * 50 * 7.583 * 0.32
    wood = int(kgOfWood) * 2.778 * 0.25

    acTotal = natgas + coal + wood + oil


    ## Food Calculation
    foodBeef = float(foodBeef)
    foodLamb = float(foodLamb)
    foodPork = float(foodPork)
    foodChicken = float(foodChicken)
    foodEggs = float(foodEggs)
    foodTofu = float(foodTofu)
    foodFish = float(foodFish)
    foodNuts = float(foodNuts)

    foodTotal = foodBeef * 25 * 0.22 + foodLamb * 20 * 0.21 + foodPork * 6.5 * 0.23 + foodChicken * 4.3 * 0.38 + foodEggs * 3.8 * 0.06 + foodTofu * 1.6 * 0.1 + foodFish * 3.5 * 0.39 - foodNuts * 0.8 * 0.27

    foodTotal += int(eatOutTimes) * 8
    foodTotal += 11.5
    foodTotal -= float((0.68 * int(percentLocallySourced)) / 100)

    ## Waste
    recyclesPaper = request.form['recyclesPaper']

    recyclesPlastic = request.form['recyclesPlastic']

    recyclesGlass = request.form['recyclesGlass']

    print(recyclesPaper)
    print(recyclesPlastic)
    print(recyclesGlass)
    #Waste Calculation

    # Paper
    if recyclesPaper == "yes":
        wasteTotal += 8.309625
    else:
        wasteTotal += 8.3125

    # Metals
    wasteTotal += (0.25 * 8.14 * 6.3)
    # Plastic
    if recyclesPlastic == "no":
        wastetotal += (9.12 * 0.25 * 3)
    else:
        wasteTotal += ((9.12 * 0.25) * 3 - 0.46 * 0.9 * (9.12 * 0.25))

    # Glass
    if recyclesGlass == "no":
        wasteTotal += (1.25 * 3.19)
    else:
        wasteTotal += (3.19 * 0.94)

    totalEmissions = acTotal + drivingTotal + foodTotal + wasteTotal
    print(totalEmissions)
# Go to nest page --> pass total
    return render_template('results.html', total_year=totalEmissions, total_week=(totalEmissions/52))


if __name__ == "__main__":
    app.run()
