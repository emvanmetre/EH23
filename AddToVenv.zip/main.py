from flask import Flask, render_template, request
import pandas as pd

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")

# Code for routing to other pages -- implement later
# @app.route("/contact")
# def contact():
#     return render_template("contact.html", prompt="Zipcode", prompt_sel="Select a topic...")
#
#
# @app.route("/about-us")
# def about():
#     return render_template("about.html")


if __name__ == "__main__":
    app.run()
